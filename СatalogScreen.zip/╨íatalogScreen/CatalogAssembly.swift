import UIKit

protocol ICatalogAssembly: AnyObject {
    func configure(with viewController: CatalogViewController)
}

class CatalogAssembly: ICatalogAssembly {
    func configure(with viewController: CatalogViewController) {
        let presenter = CatalogPresenter(view: viewController)
        let interactor = CatalogInteractor(presenter: presenter)
        let router = CatalogRouter(viewController: viewController)
        
        viewController.presenter = presenter
        presenter.interactor = interactor
        presenter.router = router
        interactor.network = NetworkProducts(delegate: viewController)
    }
}

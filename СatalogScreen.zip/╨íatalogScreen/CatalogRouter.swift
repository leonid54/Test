import UIKit

protocol ICatalogRouter: AnyObject {
    func goToSearchVC()
    func goToCategoryPopUp(categories: [CategoriesData])
}

final class CatalogRouter: ICatalogRouter {
    weak var viewController: CatalogViewController?
    
    init(viewController: CatalogViewController) {
        self.viewController = viewController
    }
    
    func goToSearchVC() {
        guard let searchVC = self.viewController?.storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as? SearchViewController else {return}
        self.viewController?.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    func goToCategoryPopUp(categories: [CategoriesData]) {
        guard let categoryPopUpVC = self.viewController?.storyboard?.instantiateViewController(withIdentifier: "CategoryPopUp") as? CategoryPopUp else {return}
        categoryPopUpVC.categories = categories
        categoryPopUpVC.modalPresentationStyle = .overFullScreen
        self.viewController?.navigationController?.present(categoryPopUpVC, animated: true)
    }
}

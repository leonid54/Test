import UIKit
protocol ICatalogViewController: AnyObject {

}

final class CatalogViewController: UIViewController, ICatalogViewController {
    var presenter: ICatalogPresenter!
    let configurator: ICatalogAssembly = CatalogAssembly()
    
    var refreshController = UIRefreshControl()
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var searchContentView: UIView!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var filterButton: UIButton!
    @IBOutlet weak var topCatalogCollectionView: UICollectionView!
    @IBOutlet weak var sertificatLabel: UILabel!
    @IBOutlet weak var sertificatContentView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nameTextField: WhiteTextField!
    @IBOutlet weak var surnameLabel: UILabel!
    @IBOutlet weak var surnameTextField: WhiteTextField!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var priceTextField: WhiteTextField!
    @IBOutlet weak var buyButton: RedButton!
    @IBOutlet weak var productLabel: UILabel!
    @IBOutlet weak var bottomCatalogCollectionView: UICollectionView!
    @IBOutlet weak var bottomCollectionViewHeight: NSLayoutConstraint!

    private let topSectionInsets = UIEdgeInsets(top: 20.0, left: 18.0, bottom: 14.0, right: 18.0)
    private let bottomSectionInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
    
    private let categories_id: [String] = []
    var onSelectedCellHandler: (() -> Void)?

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.setHeightForCollection()
        self.configureAppearance()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configurator.configure(with: self)
        presenter.configureView()
        configure()
        self.refreshController.addTarget(self, action: #selector(refreshView) , for: .valueChanged)
        self.scrollView.refreshControl = self.refreshController
        self.presenter.interactor.getCategories()
        self.presenter.interactor.getProducts()
    }
    
    @IBAction func goToSearchAction(_ sender: Any) {
        self.presenter.router.goToSearchVC()
    }
    
    @IBAction func goToFilterAction(_ sender: Any) {
        self.presenter.router.goToCategoryPopUp(categories: self.presenter.categories)
    }
    
    @objc func refreshView(_ sender: Any) {
        self.presenter.interactor.getCategories()
        self.presenter.interactor.getProducts()
    }
}

private extension CatalogViewController {
    func configure() {
        self.setContent()
        self.addDelegate()
        self.setCell()
        self.hideKeyboardWhenTappedAround()
    }
    
    func addDelegate() {
        self.topCatalogCollectionView.delegate = self
        self.topCatalogCollectionView.dataSource = self
        self.topCatalogCollectionView.collectionViewLayout = UICollectionViewFlowLayout()
        self.bottomCatalogCollectionView.delegate = self
        self.bottomCatalogCollectionView.dataSource = self
        self.bottomCatalogCollectionView.collectionViewLayout = UICollectionViewFlowLayout()
    }
    
    func setCell() {
        self.topCatalogCollectionView.register(TopCatalogCollectionViewCell.uiNib, forCellWithReuseIdentifier: TopCatalogCollectionViewCell.cellIdentifierForReg)
        self.bottomCatalogCollectionView.register(BottomCatalogCollectionViewCell.uiNib, forCellWithReuseIdentifier: BottomCatalogCollectionViewCell.cellIdentifierForReg)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        self.topCatalogCollectionView.collectionViewLayout = layout
    }
    
    func setContent() {
        self.searchContentView.layer.cornerRadius = 10
        self.sertificatLabel.text = l10n("CATALOG_VIEW_SERTIFICAT_LABEL")
        self.sertificatContentView.layer.cornerRadius = 10
        self.nameLabel.text = l10n("CATALOG_VIEW_NAME_LABEL")
        self.nameTextField.textField.placeholder = ""
        self.surnameLabel.text = l10n("CATALOG_VIEW_SURNAME_LABEL")
        self.surnameTextField.textField.placeholder = ""
        self.priceLabel.text = l10n("CATALOG_VIEW_PRICE_LABEL")
        self.priceTextField.textField.placeholder = ""
        self.buyButton.setTitle(l10n("CATALOG_VIEW_BUY_BUTTON"), for: .normal)
        self.buyButton.layer.cornerRadius = 25
        self.nameTextField.textField.font = UIFont(name: "Roboto-Bold", size: 16)
        self.surnameTextField.textField.font = UIFont(name: "Roboto-Bold", size: 16)
        self.priceTextField.textField.font = UIFont(name: "Roboto-Bold", size: 16)
        self.productLabel.text = l10n("CATALOG_VIEW_PRODUCT_LABEL")
    }
    
    func configureAppearance() {
        let customView = UIView(frame: CGRect(x: 0.0, y: 0.0, width: 200.0, height: 44.0))
        let label = UILabel(frame: CGRect(x: 0.0, y: 10.0, width: 200.0, height: 32.0))
        label.text = l10n("CATALOG_VIEW_TITLE")
        label.textColor = UIColor.Text.defaultBlack
        label.font = UIFont(name: "Roboto-BoldItalic", size: 24.0)
        label.textAlignment = NSTextAlignment.left
        label.backgroundColor = UIColor.Background.applicationYellow
        customView.addSubview(label)
        let leftButton = UIBarButtonItem(customView: customView)
        self.navigationItem.leftBarButtonItem = leftButton
        if #available(iOS 15, *) {
            guard let navigationBar = navigationController?.navigationBar else { return }
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = UIColor.Background.applicationYellow
            appearance.shadowColor = .clear
            appearance.shadowImage = UIImage()
            appearance.titleTextAttributes = [.foregroundColor: UIColor.Text.defaultBlack ,NSAttributedString.Key.font: UIFont(name: "Roboto-BoldItalic", size: 24)!]
            navigationBar.standardAppearance = appearance
            navigationBar.scrollEdgeAppearance = navigationBar.standardAppearance
        }
    }
    
    func setHeightForCollection() {
        if self.presenter.products.count > 4 {
            self.bottomCollectionViewHeight.constant = (CGFloat(self.presenter.products.count) / 2.0) * 400.0
            self.view.layoutIfNeeded()
        }
    }
}

extension CatalogViewController: UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == topCatalogCollectionView {
            return self.presenter.categories.count
        }
        return self.presenter.products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = { () -> UICollectionViewCell in
            if collectionView == self.topCatalogCollectionView {
                let topCell = self.topCatalogCollectionView.dequeueReusableCell(withReuseIdentifier: TopCatalogCollectionViewCell.cellIdentifierForReg, for: indexPath) as! TopCatalogCollectionViewCell
                self.onSelectedCellHandler = {
                    topCell.setSelectedCell()
                }
                topCell.setContent(categories: self.presenter.categories[indexPath.row])
                return topCell
            }
            if collectionView == self.bottomCatalogCollectionView {
                let bottomCell = self.bottomCatalogCollectionView.dequeueReusableCell(withReuseIdentifier: BottomCatalogCollectionViewCell.cellIdentifierForReg, for: indexPath) as! BottomCatalogCollectionViewCell
                bottomCell.setContent(product: self.presenter.products[indexPath.row])
                bottomCell.countersView.product_id = self.presenter.products[indexPath.row].id
                return bottomCell
            }
            return UICollectionViewCell.init()
        }()
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.bottomCatalogCollectionView {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailedCatalogViewController") as! DetailedCatalogViewController
            vc.setModel(product: self.presenter.products[indexPath.row])
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        if collectionView == self.topCatalogCollectionView {
            self.onSelectedCellHandler?()
        }
    }
}

extension CatalogViewController: UICollectionViewDelegate {
    
}

extension CatalogViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == self.bottomCatalogCollectionView {
            let paddingSpace = bottomSectionInsets.left * (2 + 1)
            let availableWidth = self.view.frame.width - paddingSpace
            let widthPerItem = availableWidth / 2
            
            return CGSize(width: widthPerItem, height: 277)
        }
        
        if collectionView == self.topCatalogCollectionView {
            return CGSize(width: 59, height: 100)
        }
        return CGSize()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if collectionView == self.bottomCatalogCollectionView {
            return bottomSectionInsets
        }
        
        if collectionView == self.topCatalogCollectionView {
            return topSectionInsets
        }
        return bottomSectionInsets
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == self.bottomCatalogCollectionView {
            return bottomSectionInsets.left
        }
        
        if collectionView == self.topCatalogCollectionView {
            return topSectionInsets.left
        }
        return bottomSectionInsets.left
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == self.bottomCatalogCollectionView {
            return 20
        }
        
        if collectionView == self.topCatalogCollectionView {
            return 25
        }
        return CGFloat()
    }
}

extension CatalogViewController: ProductsDelegate {
    func categoriesList(list: [CategoriesData]) {
        if !list.isEmpty {
            self.presenter.categories = list
            DispatchQueue.main.async {
                self.topCatalogCollectionView.reloadData()
            }
        }
    }
    
    func productsList(list: [ProductsData], total: Int) {
        if !list.isEmpty {
            self.presenter.products = list
            DispatchQueue.main.async {
                self.setHeightForCollection()
                self.bottomCatalogCollectionView.reloadData()
                self.refreshController.endRefreshing()
            }
        }
    }
}

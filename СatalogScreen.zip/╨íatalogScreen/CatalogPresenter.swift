import UIKit

protocol ICatalogPresenter: AnyObject {
    var router: ICatalogRouter! {set get}
    var interactor: ICatalogInteractor! {set get}
    func configureView()
    var categories: [CategoriesData] {set get}
    var products: [ProductsData] {set get}
}

final class CatalogPresenter: ICatalogPresenter {
    var router: ICatalogRouter!
    var interactor: ICatalogInteractor!
    weak var view: ICatalogViewController!
    
    var categories: [CategoriesData] = []
    var products: [ProductsData] = []
    
    required init(view: ICatalogViewController){
        self.view = view
    }
    
    func configureView() {
    }
}

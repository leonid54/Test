import UIKit

protocol ICatalogInteractor: AnyObject {
    func getCategories()
    func getProducts()
}

final class CatalogInteractor: ICatalogInteractor {
    weak var presenter: ICatalogPresenter!

    var network: NetworkProducts?

    required init(presenter: ICatalogPresenter) {
        self.presenter = presenter
    }
    
    func getCategories() {
        self.network?.getCategories()
    }
    
    func getProducts() {
        self.network?.getAllProducts()
    }
}

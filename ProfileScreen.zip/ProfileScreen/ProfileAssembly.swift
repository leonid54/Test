import UIKit

protocol IProfileAssembly: AnyObject {
    func configure(with viewController: ProfileViewController)
}

class ProfileAssembly: IProfileAssembly {
    func configure(with viewController: ProfileViewController) {
        let presenter = ProfilePresenter(view: viewController)
        let interactor = ProfileInteractor(presenter: presenter)
        let router = ProfileRouter(viewController: viewController)
        
        viewController.presenter = presenter
        presenter.interactor = interactor
        presenter.router = router
        interactor.network = NetworkAuthorization(delegate: viewController)
    }
}

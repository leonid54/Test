import UIKit

protocol IProfilePresenter: AnyObject {
    var router: IProfileRouter! {set get}
    func configureView()
    var interactor: IProfileInteractor! {set get}
    var userList: UserInfoData? {set get}
}

final class ProfilePresenter: IProfilePresenter {
    
    var router: IProfileRouter!
    var interactor: IProfileInteractor!
    weak var view: IProfileViewController!
    
    var userList: UserInfoData?
        
    required init(view: IProfileViewController) {
        self.view = view
    }
    
    func configureView() {
    }
}

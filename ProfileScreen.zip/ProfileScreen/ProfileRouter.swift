import UIKit

protocol IProfileRouter: AnyObject {
    
}

final class ProfileRouter: IProfileRouter {
    weak var viewController: ProfileViewController?
    
    init(viewController: ProfileViewController) {
        self.viewController = viewController
    }
}

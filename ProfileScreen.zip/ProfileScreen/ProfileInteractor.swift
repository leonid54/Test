import UIKit

protocol IProfileInteractor: AnyObject {
    func editProfile(name: String, city: String, phone: String, email: String)
    func changeProfilePassword(old_password: String, new_password: String, repeat_password: String)
    func getUserInfo(user_id: String)
    func changeUserPhoto(file: Data)
    func deleteUserPhoto()
}

final class ProfileInteractor: IProfileInteractor {
    weak var presenter: IProfilePresenter!
    
    var network: NetworkAuthorization?

    required init(presenter: IProfilePresenter) {
        self.presenter = presenter
    }
    
    func editProfile(name: String, city: String, phone: String, email: String) {
        self.network?.editProfile(name: name, city: city, phone: phone, email: email)
    }
    
    func changeProfilePassword(old_password: String, new_password: String, repeat_password: String) {
        self.network?.changeProfilePassword(old_password: old_password, new_password: new_password, repeat_password: repeat_password)
    }
    
    func getUserInfo(user_id: String) {
        self.network?.getUserInfo(user_id: user_id)
    }
    
    func changeUserPhoto(file: Data) {
        self.network?.changeUserPhoto(file: file)
    }
    
    func deleteUserPhoto() {
        self.network?.deleteUserPhoto()
    }
}

import UIKit

protocol ISearchRouter: AnyObject {
    func goToCategoryPopUp()
}

final class SearchRouter: ISearchRouter {
    weak var viewController: SearchViewController?
    
    init(viewController: SearchViewController) {
        self.viewController = viewController
    }
    
    func goToCategoryPopUp() {
        guard let categoryPopUpVC = self.viewController?.storyboard?.instantiateViewController(withIdentifier: "CategoryPopUp") as? CategoryPopUp else {return}
        categoryPopUpVC.modalPresentationStyle = .overFullScreen
        self.viewController?.navigationController?.present(categoryPopUpVC, animated: true)
    }
}

import UIKit

protocol ISearchPresenter: AnyObject {
    var router: ISearchRouter! {set get}
    func configureView()
    var interactor: ISearchInteractor! {set get}
    var products: [ProductsData] {set get}
}

final class SearchPresenter: ISearchPresenter {
    var router: ISearchRouter!
    var interactor: ISearchInteractor!
    weak var view: ISearchViewController!
    
    var products: [ProductsData] = []
    
    required init(view: ISearchViewController){
        self.view = view
    }
    
    func configureView() {
    }
}

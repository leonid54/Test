import UIKit

protocol ISearchInteractor: AnyObject {
    func searchProduct(search: String)
}

final class SearchInteractor: ISearchInteractor {
    weak var presenter: ISearchPresenter!

    var network: NetworkProducts?
    
    required init(presenter: ISearchPresenter) {
        self.presenter = presenter
    }
    
    func searchProduct(search: String) {
        self.network?.getAllProducts(search: search)
    }
}

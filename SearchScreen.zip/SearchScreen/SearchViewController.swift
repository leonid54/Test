import UIKit
protocol ISearchViewController: AnyObject {
    
}

final class SearchViewController: UIViewController, ISearchViewController {
    
    var presenter: ISearchPresenter!
    let configurator: ISearchAssembly = SearchAssembly()
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var searchContentView: UIView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var filterButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var searchTableView: UITableView!
    @IBOutlet weak var searchTableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var emptyView: EmptyView!
        
    var searchActive : Bool = false
    var data: [String] = []
    var filtered:[String] = []
    var allList: [Any] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.configureAppearance()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configurator.configure(with: self)
        presenter.configureView()
        configure()
        self.isHistoryEmpty()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    @IBAction func clearButtonAction(_ sender: Any) {
        SearchHistoryTableViewCell.searchHistoryList.removeAll()
        self.searchTableView.reloadData()
    }
    
    @IBAction func goToFilterAction(_ sender: Any) {
        self.presenter.router.goToCategoryPopUp()
    }
}

private extension SearchViewController {
    func configure() {
        self.setContent()
        self.hideKeyboardWhenTappedAround()
        self.addDelegate()
        self.setCell()
        self.setSearchBar()
    }
    
    func addDelegate() {
        self.searchTableView.delegate = self
        self.searchTableView.dataSource = self
        self.searchBar.delegate = self
    }
    
    func setCell() {
        self.searchTableView.register(SearchHistoryTableViewCell.uiNib, forCellReuseIdentifier: SearchHistoryTableViewCell.cellIdentifierForReg)
        self.searchTableView.register(SearchResultTableViewCell.uiNib, forCellReuseIdentifier: SearchResultTableViewCell.cellIdentifierForReg)
        
        self.searchTableView.separatorStyle = .none
    }
    
    func setList() {
        for list in self.filtered {
            self.allList.append(list)
        }
    }
    
    func isHistoryEmpty() {
        if SearchHistoryTableViewCell.searchHistoryList.isEmpty {
            self.scrollView.isHidden = true
        } else {
            self.scrollView.isHidden = false
        }
    }
    
    func setSearchBar() {
        if let searchField = searchBar.value(forKey: "searchField") as? UITextField {
            searchField.backgroundColor = UIColor.Text.defaultWhite
            searchField.textColor = UIColor.Text.defaultBlack
            let attributesForPlaceHolder = [NSAttributedString.Key.foregroundColor: UIColor.Text.placeholder,
                                            .font : UIFont(name: "Roboto-Regular", size: 18)]
            
            searchField.attributedPlaceholder = NSAttributedString(string: "поиск", attributes: attributesForPlaceHolder as [NSAttributedString.Key : Any])
            searchField.font = UIFont(name: "Roboto-Regular", size: 18)
            
//            searchField.subviews.forEach({ view in
//                view.layer.cornerRadius = 10
//                view.clipsToBounds = true
//            })
            
            
            if let leftView = searchField.leftView as? UIImageView {
                leftView.image = leftView.image?.withRenderingMode(.alwaysTemplate)
                leftView.tintColor = UIColor.Text.placeholder
            }
        }
    }
    
    func setContent() {
        self.emptyView.headerLabel.text = l10n("История поиска пуста")
        self.emptyView.contentHeight.constant = CGFloat(-60)
        self.clearButton.setTitle("Очистить", for: .normal)
        self.clearButton.setTitleColor(UIColor.Text.defaultBlack, for: .normal)
        self.searchContentView.layer.cornerRadius = 10
        self.searchBar.searchBarStyle = .prominent
    }
    
    func configureAppearance() {
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        let customView = UIView(frame: CGRect(x: 0.0, y: 0.0, width: 200.0, height: 44.0))
        let label = UILabel(frame: CGRect(x: 0.0, y: 10.0, width: 200.0, height: 32.0))
        label.text = l10n("Поиск")
        label.textColor = UIColor.Text.defaultBlack
        label.font = UIFont(name: "Roboto-BoldItalic", size: 24.0)
        label.textAlignment = NSTextAlignment.left
        label.backgroundColor = UIColor.Background.applicationYellow
        customView.addSubview(label)
        let leftButton = UIBarButtonItem(customView: customView)
        self.navigationItem.leftBarButtonItem = leftButton
        if #available(iOS 15, *) {
            guard let navigationBar = navigationController?.navigationBar else { return }
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = UIColor.Background.applicationYellow
            appearance.shadowColor = .clear
            appearance.shadowImage = UIImage()
            appearance.titleTextAttributes = [.foregroundColor: UIColor.Text.defaultBlack ,NSAttributedString.Key.font: UIFont(name: "Roboto-BoldItalic", size: 24)!]
            navigationBar.standardAppearance = appearance
            navigationBar.scrollEdgeAppearance = navigationBar.standardAppearance
        }
    }
    
}

extension SearchViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 {
            let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 21))
            let label = UILabel()
            label.frame = CGRect.init(x: 16, y: 0, width: 120, height: 21)
            label.text = "История"
            label.font = UIFont(name: "Roboto-Medium", size: 18)
            label.textColor = UIColor.Text.defaultBlack
            headerView.addSubview(label)
            return headerView
        }
        if section == 1 {
            let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 21))
            let label = UILabel()
            label.frame = CGRect.init(x: 16, y: 0, width: 120, height: 21)
            label.text = "Результаты"
            label.font = UIFont(name: "Roboto-Medium", size: 18)
            label.textColor = UIColor.Text.defaultBlack
            headerView.addSubview(label)
            return headerView
        }
        return UIView.init()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return SearchHistoryTableViewCell.searchHistoryList.count
        } else {
            if(searchActive) {
                return self.filtered.count
            }
        }
        return 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 && !SearchHistoryTableViewCell.searchHistoryList.isEmpty{
            let cell = self.searchTableView.dequeueReusableCell(withIdentifier: SearchHistoryTableViewCell.cellIdentifierForReg, for: indexPath) as! SearchHistoryTableViewCell
            cell.label?.text = SearchHistoryTableViewCell.searchHistoryList[indexPath.row]
            cell.setContent()
            cell.onDeleteButtonHandler = {
                SearchHistoryTableViewCell.searchHistoryList.remove(at: indexPath.row)
                tableView.reloadData()
            }
            return cell
        } else {
            let cell = self.searchTableView.dequeueReusableCell(withIdentifier: SearchResultTableViewCell.cellIdentifierForReg, for: indexPath) as! SearchResultTableViewCell
            cell.setContent(product: self.presenter.products[indexPath.row])
            return cell
        }
    }
}

extension SearchViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 && !SearchHistoryTableViewCell.searchHistoryList.isEmpty {
            self.searchBar.text = SearchHistoryTableViewCell.searchHistoryList[indexPath.row]
        } else {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailedCatalogViewController") as! DetailedCatalogViewController
            vc.setModel(product: self.presenter.products[indexPath.row])
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension SearchViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.scrollView.isHidden = false

        self.filtered = SearchHistoryTableViewCell.searchHistoryList.filter({ (text) -> Bool in
            let tmp: NSString = text as NSString
            let range = tmp.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
            return range.location != NSNotFound
        })
        if(self.filtered.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.searchTableView.reloadData()
    }
    
    
    func searchBarSearchButtonClicked(_ seachBar: UISearchBar) {
        if self.searchBar.text != "" {
            self.presenter.interactor.searchProduct(search: self.searchBar.text ?? "")
            if !SearchHistoryTableViewCell.searchHistoryList.contains(self.searchBar.text ?? "") {
                SearchHistoryTableViewCell.searchHistoryList.append(self.searchBar.text ?? "")
                self.setList()
            } else {
                return
            }
        }
        self.searchTableView.reloadData()
    }
}

extension SearchViewController: ProductsDelegate {
    func productsList(list: [ProductsData], total: Int) {
        if !list.isEmpty {
            self.presenter.products = list
            DispatchQueue.main.async {
                self.searchTableView.reloadData()
            }
        }
    }
}

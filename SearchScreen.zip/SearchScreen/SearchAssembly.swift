import UIKit

protocol ISearchAssembly: AnyObject {
    func configure(with viewController: SearchViewController)
}

class SearchAssembly: ISearchAssembly {
    func configure(with viewController: SearchViewController) {
        let presenter = SearchPresenter(view: viewController)
        let interactor = SearchInteractor(presenter: presenter)
        let router = SearchRouter(viewController: viewController)
        
        viewController.presenter = presenter
        presenter.interactor = interactor
        presenter.router = router
        interactor.network = NetworkProducts(delegate: viewController)
    }
}
